---
rule_id: MAP-SLEEVE-001
title: Amplify Rep-as-PM UMA Sleeve to Orion Model Composition
scope: source_to_canonical
entity: Sleeve / Model
status: APPROVED
version: 1.0.0
owner: Domain SME / Migration Lead
effective_from: 2026-10-01
approval_required: true
---

# Rule Title: Amplify Rep-as-PM UMA Sleeve Conversion

## Intent
Translate custom Rep-as-PM sleeve allocations from Amplify into Orion-compatible Model Aggregates and Compositions while preserving exact portfolio weightings.

## Inputs
- amplify_account_sleeve.sleeve_id
- amplify_account_sleeve.account_number
- amplify_account_sleeve.model_code
- amplify_account_sleeve.target_pct
- amplify_model_master.is_custom_rep_pm

## Logic
1. Filter Amplify sleeve rows where is_custom_rep_pm = TRUE.
2. Group sleeves by account_number and model_code.
3. Normalize target weights:
   W_canonical = target_pct / 100.0000
4. Enforce Invariant:
   Sum(W_canonical) = 1.0000
5. Map normalized weights to Orion ModelComposition target percentages.

## Edge Cases
- **Null or Zero Weights:** If target_pct <= 0, flag as CRITICAL_EXEMPTION and do not process.
- **Rounding Drift:** If the sum of sleeve weights equals 0.9999 or 1.0001 due to floating-point representation, adjust the largest sleeve allocation to force the sum to 1.0000.
- **Orphan Model Code:** If model_code does not exist in Orion Core Models, create an advisor-level custom model shell in Orion before linking.

## Validation & Reconciliation
- Assert sum of weights = 1.0000.
- Compare pre-transform sleeve count with post-transform Orion composition row count.
- Tolerance: 0.00% deviation in weight sum.

## Approval
- **Approved By:** Lead Domain SME & Migration Architect
- **Status:** APPROVED
- **Timestamp:** 2026-09-30T10:00:00Z